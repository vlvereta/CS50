<?php
    
    require(__DIR__ . '/database.php');

    /** Database connection */
    try {
        $db = new PDO($DB_DSN, $DB_USER, $DB_PASSWORD);
        $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    } catch (Exception $e) {
        echo 'Database connection failed: ' . $e->getMessage();
        die();
    }

    /** Database configuration */
    $users = $db->query('CREATE TABLE IF NOT EXISTS users
        (
            id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
            username VARCHAR(50) NOT NULL UNIQUE,
            email VARCHAR(255) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            is_admin BOOLEAN NOT NULL DEFAULT FALSE,
            is_confirmed BOOLEAN DEFAULT FALSE,
            is_likes BOOLEAN DEFAULT TRUE,
            is_comments BOOLEAN DEFAULT TRUE,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ');

    $pictures = $db->query('CREATE TABLE IF NOT EXISTS pictures
        (
            id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
            user_id INT NOT NULL,
            picture BLOB NOT NULL,
            filter VARCHAR(50),
            additional_id VARCHAR(50),
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ');

    $likes = $db->query('CREATE TABLE IF NOT EXISTS likes
        (
            id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
            user_id INT NOT NULL,
            picture_id INT NOT NULL
        )
    ');
    
    $comments = $db->query('CREATE TABLE IF NOT EXISTS comments
        (
            id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
            user_id INT NOT NULL,
            picture_id INT NOT NULL,
            text VARCHAR(1000) NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP        
        )
    ');
