<?php

    /** Check a host ip! Has to be:
     *  a result of docker-machine ip
     *  or
     *  a result of docker inspect -f '{{range .NetworkSettings.Networks}}{{.IPAddress}}{{end}}' camagru_mysql_1
    */
    $DB_DSN = 'mysql:host=mysql;dbname=camagru';
    $DB_USER = 'camagru';
    $DB_PASSWORD = 'secret';
    