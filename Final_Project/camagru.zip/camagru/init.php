<?php

    define("__ROOT__", __DIR__ . "/");

    require_once(__ROOT__ . '/config/setup.php');

    require(__ROOT__ . '/api/lib/dev.php');
    require(__ROOT__ . '/api/lib/helpers.php');
    require(__ROOT__ . '/api/router.php');

    require(__ROOT__ . '/api/services/auth.php');
    require(__ROOT__ . '/api/services/mail.php');
    
    require(__ROOT__ . '/api/models/auth.php');
    require(__ROOT__ . '/api/models/pictures.php');

    if (!$db->query('SELECT * FROM users')->fetchAll(PDO::FETCH_ASSOC)) {
        $db->query('INSERT INTO users (username, email, password, is_admin, is_confirmed)
        VALUES
            (
                "admin",
                "admin@email.com",
                "$2y$10$ZbFZQGw4TZ/rn7Nt3AvZ..LvESqcfQn30VtkUFo5wsXf0g6pRB1nS",
                TRUE,
                TRUE
            )
        ');
        $db->query('INSERT INTO users (username, email, password, is_confirmed)
        VALUES
            (
                "Dhorean",
                "dhorean@email.com",
                "$2y$10$ZbFZQGw4TZ/rn7Nt3AvZ..LvESqcfQn30VtkUFo5wsXf0g6pRB1nS",
                TRUE
            )
        ');
    }
