<?php

    function createUser($username, $email, $password) {
        global $db;
        
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $sql = 'INSERT INTO users (username, email, password, is_admin, is_confirmed) VALUES (:username, :email, :password, 0, 0)';
        $stmt = $db->prepare($sql);
        $stmt->execute([
            ':username' => $username,
            ':email'    => $email,
            ':password' => $hashed_password
        ]);

        sendConfirmationEmail($username, $email, $hashed_password);
    }

    function updateUser($id, $username, $email, $password) {
        global $db;

        if ($password) {
            $sql = 'UPDATE users SET username = :username, email = :email, password = :password WHERE id = :id';
            $stmt = $db->prepare($sql);
            $stmt->execute([
                ':username' => $username,
                ':email'    => $email,
                ':password' => password_hash($password, PASSWORD_DEFAULT),
                ':id'       => $id
            ]);
        } else {
            $sql = 'UPDATE users SET username = :username, email = :email WHERE id = :id';
            $stmt = $db->prepare($sql);
            $stmt->execute([
                ':username' => $username,
                ':email'    => $email,
                ':id'       => $id
            ]);
        }
    }

    function updateUserConfirmation($user_id)
    {
        global $db;

        $sql = 'UPDATE users SET is_confirmed = true WHERE id = :id';
        $stmt = $db->prepare($sql);
        $stmt->execute([
            ':id' => $user_id
        ]);
    }

    function updateUserPassword($username, $password)
    {
        global $db;

        $sql = 'UPDATE users SET password = :password WHERE username = :username';
        $stmt = $db->prepare($sql);
        $stmt->execute([
            ':password' => password_hash($password, PASSWORD_DEFAULT),
            ':username' => $username
        ]);
    }

    function updatePreferences($id, $is_likes, $is_comments)
    {
        global $db;

        $sql = 'UPDATE users SET is_likes = :is_likes, is_comments = :is_comments WHERE id = :id';
        $stmt = $db->prepare($sql);
        $stmt->execute([
            ':is_likes'     => $is_likes,
            ':is_comments'  => $is_comments,
            ':id'           => $id
        ]);
    }

    function getUserById($id)
    {
        global $db;

        $sql = 'SELECT username, email, is_confirmed, is_likes, is_comments, created_at FROM users WHERE id = :id LIMIT 1';
        $stmt = $db->prepare($sql);
        $stmt->execute([
            ':id' => $id
        ]);
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return reset($result);
    }

    function getUserByUsername($username) {
        global $db;
        
        $sql = 'SELECT * FROM users WHERE username = :username LIMIT 1';
        $stmt = $db->prepare($sql);
        $stmt->execute([
            ':username' => $username
        ]);
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return reset($result);
    }

    function getUserByEmail($email) {
        global $db;
        
        $sql = 'SELECT * FROM users WHERE email = :email LIMIT 1';
        $stmt = $db->prepare($sql);
        $stmt->execute([
            ':email' => $email
        ]);
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return reset($result);
    }
