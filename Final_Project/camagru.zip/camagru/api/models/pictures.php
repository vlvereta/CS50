<?php

    function storeNewPicture($request, $user_id)
    {
        global $db;

        $id = $request['id'];
        $picture = $request['picture'];
        $picture_filter = $request['filter'];

        $sql = 'INSERT INTO pictures (user_id, picture, filter, additional_id) VALUES (:user_id, :picture, :filter, :additional_id)';
        $stmt = $db->prepare($sql);
        $stmt->execute([
            ':user_id'          => $user_id,
            ':picture'          => $picture,
            ':filter'           => $picture_filter,
            ':additional_id'    => $id
        ]);

        $sql2 = 'SELECT picture, filter FROM pictures WHERE additional_id = :additional_id ';
        $stmt2 = $db->prepare($sql2);
        $stmt2->execute([
            ':additional_id'  => $id
        ]);
        $result = $stmt2->fetchAll(PDO::FETCH_ASSOC);

        return $result[0];
    }

    function deletePictureById($picture_id)
    {
        global $db;

        $sql = 'DELETE FROM pictures WHERE id = :picture_id';
        $stmt = $db->prepare($sql);
        $stmt->execute([
            ':picture_id'   => $picture_id
        ]);
    }

    function getPicturesByUserId($user_id)
    {
        global $db;

        $sql = 'SELECT id, picture, filter FROM pictures WHERE user_id = :user_id';
        $stmt = $db->prepare($sql);
        $stmt->execute([
            ':user_id'  => $user_id
        ]);
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    function getPictures($min, $max)
    {
        global $db;

        $sql = "SELECT id, user_id, picture, filter, created_at FROM pictures WHERE id >= $min AND id < $max";
        $stmt = $db->prepare($sql);
        $stmt->execute();
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        if ($result && count($result)) {
            $sql = 'SELECT username FROM users WHERE id = :user_id';
            $stmt = $db->prepare($sql);

            foreach ($result as $i => $r) {
                $stmt->execute([
                    ':user_id'  => $r['user_id']
                ]);
                $result2 = $stmt->fetchAll(PDO::FETCH_ASSOC);
                $result[$i]['username'] = $result2[0]['username'];
            }
        }
        return $result;
    }

    function getLikes($picture_id)
    {
        global $db;

        $sql = 'SELECT user_id FROM likes WHERE picture_id = :picture_id';
        $stmt = $db->prepare($sql);
        $stmt->execute([
            'picture_id'    => $picture_id
        ]);
        $result = $stmt->fetchAll(PDO::FETCH_COLUMN, 0);

        return $result;
    }

    function like($picture_id, $user_id)
    {
        global $db;

        $likes = getLikes($picture_id);
        $is_liked = $likes && array_search($user_id, $likes) !== false;

        $sql = $is_liked
            ? 'DELETE FROM likes WHERE user_id = :user_id AND picture_id = :picture_id'
            : 'INSERT INTO likes(user_id, picture_id) VALUES (:user_id, :picture_id)';
        $stmt = $db->prepare($sql);
        $stmt->execute([
            'user_id'       => $user_id,
            'picture_id'    => $picture_id
        ]);

        return [
            'total'     => $likes ? $is_liked ? count($likes) - 1 : count($likes) + 1 : 1,
            'isLiked'   => !$is_liked
        ];
    }

    function getComments($picture_id)
    {
        global $db;

        $sql = 'SELECT user_id, username, text FROM comments INNER JOIN users ON comments.user_id=users.id WHERE picture_id = :picture_id';
        $stmt = $db->prepare($sql);
        $stmt->execute([
            'picture_id'    => $picture_id
        ]);
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result;
    }

    function comment($picture_id, $comment, $user_id)
    {
        global $db;

        $sql = 'INSERT INTO comments(user_id, picture_id, text) VALUES (:user_id, :picture_id, :text)';
        $stmt = $db->prepare($sql);
        $stmt->execute([
            ':user_id'      => $user_id,
            ':picture_id'   => $picture_id,
            ':text'         => $comment
        ]);
    }

    function getPictureOwner($picture_id)
    {
        global $db;

        $sql = 'SELECT username, email, is_likes, is_comments FROM pictures INNER JOIN users ON pictures.user_id = users.id WHERE pictures.id = :picture_id';
        $stmt = $db->prepare($sql);
        $stmt->execute([
            'picture_id'    => $picture_id
        ]);
        $result = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return $result[0];    
    }
