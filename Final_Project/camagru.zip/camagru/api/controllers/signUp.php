<?php

    require('../../init.php');

    $request = getRequestJson();

    $username = $request['username'];
    if (!isUsernameValid($username)) {
        errorResponse('username', 'Bad username');
    }

    if (checkIsUserExistsByUsername($username)) {
        errorResponse('username', 'Username is taken.');
    }
    
    $email = $request['email'];
    if (!isEmailValid($email)) {
        errorResponse('email', 'Bad email');
    }

    if (checkIsUserExistsByEmail($email)) {
        errorResponse('email', 'Email is taken.');
    }

    $password = $request['password'];
    if (!isPasswordValid($password)) {
        errorResponse('password', 'Bad password.');
    }

    $passwordConfirmation = $request['passwordConfirmation'];
    if (!checkPasswordWithConfirmation($password, $passwordConfirmation)) {
        errorResponse('passwordConfirmation', 'Passwords are not the same.');
    }

    createUser($request['username'], $request['email'], $request['password']);

    successResponse();
