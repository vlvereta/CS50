<?php

    require('../../init.php');

    $request = getRequestJson();

    $username = $request['username'];
    if (!checkIsUserExistsByUsername($username)) {
        // TODO: Error page if no user for password recovery
    }

    $oldPassword = $request['oldPassword'];
    if (!verifyUserByUsername($username, $oldPassword)) {
        errorResponse('oldPassword', 'Is it really your current password?');
    }
    
    $password = $request['password'];
    if (!isPasswordValid($password)) {
        errorResponse('password', 'Bad password.');
    }

    $passwordConfirmation = $request['passwordConfirmation'];
    if (!isPasswordValid($passwordConfirmation)) {
        errorResponse('passwordConfirmation', 'Bad password.');
    }

    if (!checkPasswordWithConfirmation($password, $passwordConfirmation)) {
        errorResponse('passwordConfirmation', 'Passwords are not the same.');
    }
    
    updateUserPassword($username, $password);
    
    successResponse();
