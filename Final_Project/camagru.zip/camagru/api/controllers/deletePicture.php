<?php

    require('../../init.php');

    $request = getRequestJson();

    if ($request['picture_id']) {
        deletePictureById($request['picture_id']);
    }

    successResponse();
    