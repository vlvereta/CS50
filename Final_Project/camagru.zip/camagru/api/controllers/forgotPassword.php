<?php

    require('../../init.php');

    $request = getRequestJson();

    $email = $request['email'];
    if (!checkIsUserExistsByEmail($email)) {
        errorResponse('email', 'No user with this email.');
    }

    sendRestorePasswordEmail($email);

    successResponse();
