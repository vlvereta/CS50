<?php
    session_start();

    require('../../init.php');

    $request = getRequestJson();

    $username = $request['username'];

    if (!checkIsUserExistsByUsername($username, true)) {
        errorResponse('username', 'No user with this username.');
    }

    if (!verifyUserByUsername($username, $request['password'])) {
        errorResponse('password', 'Password doesn\'t match.');
    }

    setUserSession($username);

    successResponse();
