<?php
    session_start();

    require('../../init.php');

    $request = getRequestJson();

    if (!isset($_SESSION['logged_in_user_id'])) {
        errorResponse();
    }

    $response = null;

    if ($request['is_picture']) {
        $sticker_num = $request['sticker']++;
        
        if ($sticker_num) {
            $webcam_picture = imagecreatefromwebp($request['picture']);
            $fileName = "/var/www/html/public/assets/images/emoji-$sticker_num.png";
            $emoji = imagecreatefrompng($fileName);

            list($width_orig, $height_orig) = getimagesize($fileName);

            $resampled_emoji = imagecreatetruecolor(150, 150);
            imagealphablending($resampled_emoji, false);
            imagecopyresampled($resampled_emoji, $emoji, 0, 0, 0, 0, 100, 100, $width_orig, $height_orig);
            imagesavealpha($resampled_emoji, true);

            imagecopy($webcam_picture, $resampled_emoji, 70, 70, 0, 0, 100, 100);
            ob_start();
            imagewebp($webcam_picture);
            $bin = ob_get_clean();
        }

        $picture = [
            'picture'   => !$sticker_num ? $request['picture'] : "data:image/webp;base64," . base64_encode($bin),
            'filter'    => $request['filter'],
            'id'        => $request['id']
        ];
        $response = storeNewPicture($picture, $_SESSION['logged_in_user_id']);
    } else {
        // TODO:
    }

    successResponse($response);
