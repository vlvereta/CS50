<?php
    session_start();
    
    require('../../init.php');
    
    if (isset($_SESSION['logged_in_user'])) {
        unset($_SESSION['logged_in_user']);
        unset($_SESSION['logged_in_user_id']);
        successResponse();
    } else {
        errorResponse('', '');
    }
