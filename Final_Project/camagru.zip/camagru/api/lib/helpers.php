<?php

    function getURI()
    {
        return trim($_SERVER['REQUEST_URI'], '/');
    }

    function getRequestJson() {
        $json = file_get_contents("php://input");
        return json_decode($json, true);
    }

    function errorResponse($field = '', $message = '')
    {
        echo json_encode([
            'success'   => false,
            'error'     => [
                'field'     => $field,
                'message'   => $message
            ]
        ]);
        die();
    }

    function successResponse($response = null)
    {
        echo json_encode([
            'success'   => true,
            'data'      => $response
        ]);
    }

    // Danger function: $isByEmail without check for created user
    function setUserSession($param, $isByEmail = false)
    {
        $user = $isByEmail ? getUserByEmail($param) : getUserByUsername($param);
        $_SESSION['logged_in_user_id'] = $user['id'];
        $_SESSION['logged_in_user'] = $user['username'];
    }
    function setUserIntoSession($username)
    {
        $_SESSION['logged_in_user'] = $username;
    }
