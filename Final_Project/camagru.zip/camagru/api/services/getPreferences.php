<?php
    session_start();

    require('../../init.php');

    if (!isset($_SESSION['logged_in_user_id'])) {
        errorResponse();
    }

    $result = getUserById($_SESSION['logged_in_user_id']);

    successResponse([
        'is_likes'  => $result['is_likes'],
        'is_comments'  => $result['is_comments']
    ]);
