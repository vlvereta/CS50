<?php
    session_start();

    require('../../init.php');

    $request = getRequestJson();
    $picture_id = $request['picture_id'];

    $likes = getLikes($picture_id);
    
    $result = [
        'total'         => $likes ? count($likes) : 0,
        'isLiked'       => $likes && isset($_SESSION['logged_in_user_id']) ? array_search($_SESSION['logged_in_user_id'], $likes) !== false : false,
        'isAbleToLike'  => isset($_SESSION['logged_in_user_id'])
    ];

    successResponse($result);
    