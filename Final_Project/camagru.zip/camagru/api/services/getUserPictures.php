<?php
    session_start();

    require('../../init.php');

    if (!isset($_SESSION['logged_in_user_id'])) {
        errorResponse();
    }

    $pictures = getPicturesByUserId($_SESSION['logged_in_user_id']);

    successResponse($pictures);
