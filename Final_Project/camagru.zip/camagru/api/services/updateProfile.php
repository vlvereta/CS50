<?php
    session_start();

    require('../../init.php');

    $request = getRequestJson();

    $username = $request['username'];
    if ($username && !isUsernameValid($username)) {
        errorResponse('username', 'Bad username');
    }
    
    $email = $request['email'];
    if ($email && !isEmailValid($email)) {
        errorResponse('email', 'Bad email');
    }

    $password = $request['password'];
    $oldPassword = $request['oldPassword'];
    if ($password && !verifyUserByUsername($username, $oldPassword)) {
        errorResponse('oldPassword', 'Is it really your current password?');
    }
    if ($password && !isPasswordValid($password)) {
        errorResponse('password', 'Bad password.');
    }

    $passwordConfirmation = $request['passwordConfirmation'];
    if ($password && !checkPasswordWithConfirmation($password, $passwordConfirmation)) {
        errorResponse('passwordConfirmation', 'Passwords are not the same.');
    }

    updateUser($_SESSION['logged_in_user_id'], $username, $email, $password);
    setUserIntoSession($username);

    successResponse();
