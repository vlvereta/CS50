<?php
    session_start();

    require('../../init.php');

    $request = getRequestJson();
    $page_num = $request['page'];

    $max = $page_num * 5;
    $min = $max - 5;
    $pictures = getPictures(++$min, ++$max);

    successResponse($pictures);
