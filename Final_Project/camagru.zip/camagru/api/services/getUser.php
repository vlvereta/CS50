<?php
    session_start();

    require('../../init.php');

    $user = getUserById($_SESSION['logged_in_user_id']);

    successResponse($user);
