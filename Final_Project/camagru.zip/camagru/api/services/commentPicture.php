<?php
    session_start();

    require('../../init.php');

    $request = getRequestJson();
    $picture_id = $request['picture_id'];
    $comment = $request['comment'];

    if ($_SESSION['logged_in_user_id']) {
        $user = getPictureOwner($picture_id);
        if ($user['is_comments']) {
            sendNotification($user['username'], $user['email'], "One of your pictures was commented. Let's see how is it looking now.. ;)");
        }
        
        comment($picture_id, $comment, $_SESSION['logged_in_user_id']);
        $result = [
            'isAbleToComment'   => true,
            'picture_id'        => $picture_id,
            'username'          => $_SESSION['logged_in_user'],
            'comment'           => $comment
        ];
        successResponse($result);
    } else {
        errorResponse();
    }
    