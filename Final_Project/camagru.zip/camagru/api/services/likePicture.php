<?php
    session_start();

    require('../../init.php');

    $request = getRequestJson();
    $picture_id = $request['picture_id'];

    if ($_SESSION['logged_in_user_id']) {
        $user = getPictureOwner($picture_id);
        if ($user['is_likes']) {
            sendNotification($user['username'], $user['email'], "One of your pictures was liked (or unliked who knows). Let's see how is it looking now.. ;)");
        }
        
        $result = like($picture_id, $_SESSION['logged_in_user_id']);
        $result['isAbleToLike'] = true;
        successResponse($result);
    } else {
        errorResponse();
    }
    