<?php

    $username = $_GET['username'];
    $password_hash = $_GET['hash'];

    if (!checkIsUserExistsByUsername($username) || !verifyUserByUsername($username, $password_hash, true)) {
        return require(__ROOT__ . '/client/views/notFound.php');
    }

    confirmUser($username, $password_hash);

    return require(__ROOT__ . '/client/views/confirmation.php');
