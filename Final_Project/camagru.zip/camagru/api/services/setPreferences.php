<?php
    session_start();

    require('../../init.php');

    $request = getRequestJson();
    $is_likes = $request['likes'] ? 1 : 0;
    $is_comments = $request['comments'] ? 1 : 0;

    if ($_SESSION['logged_in_user_id']) {
        updatePreferences($_SESSION['logged_in_user_id'], $is_likes, $is_comments);
        successResponse();
    } else {
        errorResponse();
    }
    