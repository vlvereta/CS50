<?php
    session_start();

    require('../../init.php');

    $request = getRequestJson();
    $picture_id = $request['picture_id'];

    $comments = getComments($picture_id);
    $result = [
        'comments'          => $comments,
        'isAbleToComment'   => isset($_SESSION['logged_in_user_id'])
    ];

    successResponse($result);
    