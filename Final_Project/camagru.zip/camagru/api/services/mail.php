<?php

    function sendConfirmationEmail($username, $email, $password_hash) {
        $headers  = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type: text/html; charset: utf8" . "\r\n";

        $confirmation_link = "https://" . $_SERVER['HTTP_HOST'] . "/confirmation?username=" . $username . "&hash=" . $password_hash;
        $message = "
            <html>
                <head>
                    <meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\" />
                </head>
                <body>
                   <h3>Hello, $username!</h3>
                   <br/>
                   <p>
                        Please, confirm your account by clicking <a href=\"$confirmation_link\">HERE</a>.
                   </p>
                   <p>Thanks! ;)</p>
                </body>
            </html>
        ";
        
        mail($email, 'Camagru: no-reply!', $message, $headers);
    };

    function sendRestorePasswordEmail($email) {
        $user = getUserByEmail($email);

        $username = $user['username'];

        $headers  = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type: text/html; charset: utf8" . "\r\n";

        $recovery_link = "https://" . $_SERVER['HTTP_HOST'] . "/recovery-password?username=" . $username;
        $message = "
            <html>
                <head>
                    <meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\" />
                </head>
                <body>
                   <h3>Hello, $username!</h3>
                   <br/>
                   <p>
                        To reinitialize your password click <a href=\"$recovery_link\">HERE</a>.
                   </p>
                   <p>
                        If you didn't request password recovery, just ignore this letter ;)
                   </p>
                </body>
            </html>
        ";
        
        mail($email, 'Camagru: no-reply!', $message, $headers);
    };

    function sendNotification($username, $email, $text)
    {
        $headers  = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type: text/html; charset: utf8" . "\r\n";

        $message = "
            <html>
                <head>
                    <meta http-equiv=\"content-type\" content=\"text/html; charset=utf-8\" />
                </head>
                <body>
                   <h3>Hello, $username!</h3>
                   <br/>
                   <p>
                        $text
                   </p>
                   <p>Thanks! ;)</p>
                </body>
            </html>
        ";
        
        mail($email, 'Camagru: no-reply!', $message, $headers);
    }
