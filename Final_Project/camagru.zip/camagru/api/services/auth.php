<?php

    function isUsernameValid($username)
    {
        return !!preg_match('/^[a-zA-Z0-9]{3,50}$/', $username);
    }

    function isEmailValid($email)
    {
        $pattern = "/^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/";
        return !!preg_match($pattern, $email);
    }

    function isPasswordValid($password)
    {
        return !!preg_match('/^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/', $password);
    }

    function checkIsUserExistsByUsername($username, $withConfirmation = false)
    {
        $user = getUserByUsername($username);

        if (!$user) {
            return false;
        }
        return $withConfirmation ? $user['is_confirmed'] : true;
    };

    function checkIsUserExistsByEmail($email)
    {
        return getUserByEmail($email) ? true : false;
    }

    function checkPasswordWithConfirmation($password, $passwordConfirmation)
    {
        return $password === $passwordConfirmation;
    }

    function verifyUserByUsername($username, $password, $is_hash = false)
    {
        $user = getUserByUsername($username);

        if (!$user) {
            return false;
        }

        return $is_hash
            ? $password == $user['password'] 
            : password_verify($password, $user['password']);
    }

    function verifyUserByEmail($email, $password)
    {
        $user = getUserByEmail($email);

        if (!$user) {
            return false;
        }
        return password_verify($password, $user['password']);
    }

    function confirmUser($username, $hash)
    {
        $user = getUserByUsername($username);

        updateUserConfirmation($user['id']);
    }
