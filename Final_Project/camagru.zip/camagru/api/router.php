<?php

    /** Render view router */
    function renderSection()
    {
        $view = null;

        $URI = getURI();
        switch ($URI) {
            case 'sign-up':
                $view = require(__ROOT__ . '/client/views/signUp.php');
                break;
            case 'sign-in':
                $view = require(__ROOT__ . '/client/views/signIn.php');
                break;
            case 'forgot-password':
                $view = require(__ROOT__ . '/client/views/forgotPassword.php');
                break;
            case 'profile':
                $view = require(__ROOT__ . '/client/views/profile.php');
                break;
            case 'pictures':
                $view = require(__ROOT__ . '/client/views/pictures.php');
                break;
            case 'preferences':
                $view = require(__ROOT__ . '/client/views/preferences.php');
                break;
            case 'create-new-picture':
                $view = require(__ROOT__ . '/client/views/createNewPicture.php');
                break;
            case '':
                $view = require(__ROOT__ . '/client/views/main.php');
                break;
                
        // Api functional
            case !!preg_match('/^confirmation\?username=[a-zA-Z0-9]{3,50}&hash=/', $URI):
                return require(__ROOT__ . '/api/services/confirmation.php');
            case !!preg_match('/^recovery-password\?username=[a-zA-Z0-9]{3,50}$/', $URI):
                $view = require(__ROOT__ . '/client/views/recoveryPassword.php');
                break;
            default:
                $view = require(__ROOT__ . '/client/views/main.php');
        }

        return ($view);
    }
