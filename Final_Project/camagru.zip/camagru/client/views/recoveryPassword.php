<div class="columns is-centered">
    <div class="column is-4">
        <h3 class="title is-3 has-text-centered">New password</h3>
        <form onSubmit="recoveryPassword()">
            <div class="field old-password-field">
                <label class="label">Old password</label>
                <div class="control">
                    <input name="old-password" class="input old-password-input" type="password" placeholder="Old password">
                </div>
            </div>
            <div class="field password-field">
                <label class="label">Password</label>
                <div class="control">
                    <input name="password" class="input password-input" type="password" placeholder="Password">
                </div>
            </div>
            <div class="field password-confirmation-field">
                <label class="label">Confirm password</label>
                <div class="control">
                    <input name="confirm-password" class="input password-confirmation-input" type="password" placeholder="Confirm password">
                </div>
            </div>
            <div class="field">
                <div class="control">
                    <button class="button is-primary is-fullwidth" type="submit">Submit</button>
                </div>
            </div>
        </form>
    </div>
</div>

<script type="text/javascript" src="public/js/recoveryPassword.js"></script>
<script type="text/javascript" src="public/js/forms.js"></script>
<script type="text/javascript" src="public/js/validationHelpers.js"></script>
