<h3 id="title" class="title is-3 has-text-centered">Pictures</h3>
<div class="container">
    <div id="pictures" class="columns" style="flex-flow: row wrap">
        <!-- Whole cards list is building by js inside the script -->
    </div>
</div>

<script type="text/javascript" src="public/js/pictures.js"></script>
