<div id="pictures" class="container">
    <div id="greet-img" class="box has-text-centered gray-card-background" style="display: none;">
        <img style="max-height: 500px;" src="/public/assets/hello.jpg" />
    </div>
    <!-- Whole pictures list is building by js inside the script -->

</div>
<div class="container has-text-centered" style="margin-top: 2rem;">
    <button id="loader" class="button is-primary is-large is-rounded is-loading">Loading..</button>
</div>

<script type="text/javascript" src="public/js/main.js"></script>
