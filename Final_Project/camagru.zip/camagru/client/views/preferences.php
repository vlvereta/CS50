<?php
    if (!isset($_SESSION['logged_in_user'])) {
        return require(__ROOT__ . '/client/views/main.php');
    }
?>
<h3 class="title is-3 has-text-centered">Preferences</h3>
<div class="container">
    <h5 class="title is-5">Notifications:</h5>
    <form onSubmit="submitPreferences()">
        <div class="field">
            <label class="checkbox">
                <input id="likes" type="checkbox">
                when my picture was liked
            </label>
        </div>
        <div class="field">
            <label class="checkbox">
                <input id="comments" type="checkbox">
                when my picture was commented
            </label>
        </div>
        <div class="field">
            <div class="control">
                <button class="button is-primary" type="submit">Save</button>
            </div>
        </div>
    </form>
</div>

<script type="text/javascript" src="public/js/preferences.js"></script>
