<?php
    if (!isset($_SESSION['logged_in_user'])) {
        return require(__ROOT__ . '/client/views/signIn.php');
    }
?>
<div class="container">
    <div class="columns is-vcentered">
        <div class="column is-8">
            <div class="box has-text-centered">
                <h4 class="title is-4 has-text-centered">Look at yourself</h4>
                <video poster="https://euonthemove.eu/wp-content/uploads/2017/05/no-video.jpg" autoplay></video>
                <canvas style="display: none;"></canvas>
                <input id="file-input" type='file' accept="image/x-png,image/gif,image/jpeg" style="display: none;" />
                <div id="stickers" class="columns" style="flex-flow: row wrap">
                    <?php for ($i = 0; $i < 8; $i) {
    echo "
                            <div class='column is-3'>
                                <div class='box has-text-centered' style='max-width: 300px; margin: auto;'>
                                    <img src=\"../../public/assets/images/emoji-" . ++$i . ".png\" />
                                    <h3 class='title is-3'>$i</h3>
                                </div>
                            </div>
                        ";
} ?>
                </div>
                <div class="level" style="margin-top: 10px;">
                    <div class="level-left">
                        <div class="level-item">
                            <div id="filter-block" class="select is-rounded" style="display: none;">
                                <select id="filter">
                                    <option value="none">None</option>
                                    <option value="blur">Blur</option>
                                    <option value="grayscale">Grayscale</option>
                                    <option value="invert">Invert</option>
                                    <option value="sepia">Sepia</option>
                                </select>
                            </div>
                            <button id="discard" class="button is-rounded" style="display: none;">Discard</button>
                            <div id="sticker-block" class="select is-rounded">
                                <select id="sticker">
                                    <option value="0">None #</option>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="level-right">
                        <div class="level-item">
                            <button id="snapshot"
                                class="level-item button is-medium is-warning is-rounded is-static">Catch it!</button>
                            <button id="file" class="level-item button is-medium is-warning is-rounded"
                                style="display: none;">Load pic!</button>
                            <button id="save" class="button is-medium is-success is-rounded" style="display: none;">Save
                                it!</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="column is-2 is-offset-1 is-4-mobile is-offset-4-mobile">
            <div class="box" style="border: 1px solid black; padding: .3rem;">
                <img id="preview-1" style="display: inherit; border-radius: 6px;"
                    src="https://archive.org/download/no-photo-available/no-photo-available.png" />
            </div>
            <div class="box" style="border: 1px solid black; padding: .3rem;">
                <img id="preview-2" style="display: inherit; border-radius: 6px;"
                    src="https://archive.org/download/no-photo-available/no-photo-available.png" />
            </div>
            <div class="box" style="border: 1px solid black; padding: .3rem;">
                <img id="preview-3" style="display: inherit; border-radius: 6px;"
                    src="https://archive.org/download/no-photo-available/no-photo-available.png" />
            </div>
            <div class="box" style="border: 1px solid black; padding: .3rem;">
                <img id="preview-4" style="display: inherit; border-radius: 6px;"
                    src="https://archive.org/download/no-photo-available/no-photo-available.png" />
            </div>
            <div class="box" style="border: 1px solid black; padding: .3rem;">
                <img id="preview-5" style="display: inherit; border-radius: 6px;"
                    src="https://archive.org/download/no-photo-available/no-photo-available.png" />
            </div>
            <a class="box has-text-centered" href='/pictures'>Show More</a>
        </div>
    </div>
</div>

<script type="text/javascript" src="public/js/createNewPicture.js"></script>