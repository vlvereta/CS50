<?php
    if (!isset($_SESSION['logged_in_user'])) {
        return require(__ROOT__ . '/client/views/main.php');
    }
?>
<h3 class="title is-3 has-text-centered">Profile</h3>
<div class="container">
    <div class="columns is-vcentered">
        <div class="column is-4">
            <div class="box has-text-centered" style="max-width: 350px">
                <h4 id="confirmation" class="subtitle is-4" style="display: none;"></h4>
                <img src="/public/assets/avatars/user.png" />
                <button class="button is-light is-static">Change</button>
            </div>
        </div>
        <div class="column">
            <form onSubmit="updateUser()">
                <div class="field username-field">
                    <label class="label">Username</label>
                    <div class="control">
                        <input name="username" class="input username-input" type="text">
                    </div>
                </div>
                <div class="field email-field">
                    <label class="label">Email</label>
                    <div class="control">
                        <input name="email" class="input email-input" type="email">
                    </div>
                </div>
                <div class="field old-password-field">
                    <label class="label">Old password</label>
                    <div class="control">
                        <input name="old-password" class="input old-password-input" type="password">
                    </div>
                </div>
                <div class="field password-field">
                    <label class="label">Password</label>
                    <div class="control">
                        <input name="password" class="input password-input" type="password">
                    </div>
                </div>
                <div class="field password-confirmation-field">
                    <label class="label">Confirm password</label>
                    <div class="control">
                        <input name="confirm-password" class="input password-confirmation-input" type="password">
                    </div>
                </div>
                <div class="field">
                    <div class="control">
                        <button class="button is-primary is-fullwidth" type="submit">Save</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<script type="text/javascript" src="public/js/profile.js"></script>
<script type="text/javascript" src="public/js/forms.js"></script>
<script type="text/javascript" src="public/js/validationHelpers.js"></script>
