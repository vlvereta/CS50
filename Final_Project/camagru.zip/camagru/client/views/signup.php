<div class="columns is-centered">
    <div class="column is-4">
        <h3 class="title is-3 has-text-centered">Sign up</h3>
        <form onSubmit="signUp()">
            <div class="field username-field">
                <label class="label">Username</label>
                <div class="control">
                    <input name="username" class="input username-input" type="text" placeholder="Dhorean">
                </div>
            </div>
            <div class="field email-field">
                <label class="label">Email</label>
                <div class="control">
                    <input name="email" class="input email-input" type="email" placeholder="dhorean@gmail.com">
                </div>
            </div>
            <div class="field password-field">
                <label class="label">Password</label>
                <div class="control">
                    <input name="password" class="input password-input" type="password" placeholder="Password">
                </div>
            </div>
            <div class="field password-confirmation-field">
                <label class="label">Confirm password</label>
                <div class="control">
                    <input name="confirm-password" class="input password-confirmation-input" type="password" placeholder="Confirm password">
                </div>
            </div>
            <div class="field">
                <div class="control">
                    <button class="button is-primary is-fullwidth" type="submit">Sign up</button>
                </div>
            </div>
            <div class="field has-text-centered">
                <span>Already have an account? <a href="/sign-in">Sign in</a>.</span>
            </div>
        </form>
    </div>
</div>

<script type="text/javascript" src="public/js/signUp.js"></script>
<script type="text/javascript" src="public/js/forms.js"></script>
<script type="text/javascript" src="public/js/validationHelpers.js"></script>
