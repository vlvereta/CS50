<nav class="navbar has-shadow is-spaced">
    <div class="container">
        <div class="navbar-brand">
            <a class="navbar-item" href="/">
                <h2 class="title">Camagru!</h2>
            </a>
            <?php if (isset($_SESSION['logged_in_user'])) { ?>
                <a id="add-new" class="navbar-item is-hidden-desktop" onclick="redirectToCreation()" style="padding-left: 0;">
                    <div style="background-color: #ffdd57; border-radius: 50%; width: 30px; height: 30px; text-align: center; line-height: 1.7; font-size: 18px; margin-top: 3px;"><b>+</b></div>
                </a>
                <a class="navbar-item is-hidden-desktop" onclick='signOut()' style="padding-left: 0;">
                    <div style="background-color: #00d1b2; border-radius: 4px; width: 50px; height: 30px; text-align: center; line-height: 1.9; font-size: 16px; margin-top: 3px;"><b>Out</b></div>
                </a>
             <?php } else { ?>
                <a href="/sign-up" class="navbar-item is-hidden-desktop" style="padding-left: 0;">
                    <div style="background-color: #00d1b2; border-radius: 4px; width: 50px; height: 30px; text-align: center; line-height: 1.9; font-size: 16px; margin-top: 3px;"><b>Up</b></div>
                </a>
                <a href="/sign-in" class="navbar-item is-hidden-desktop" style="padding-left: 0;">
                    <div style="background-color: #f5f5f5; border-radius: 4px; width: 50px; height: 30px; text-align: center; line-height: 1.9; font-size: 16px; margin-top: 3px;"><b>In</b></div>
                </a>
             <?php } ?>
             <div id="burger" class="navbar-burger burger" data-target="navbarMenu">
                <span></span>
                <span></span>
                <span></span>
             </div>
        </div>

        <div id="navbarMenu" class="navbar-menu">
            <?php if (isset($_SESSION['logged_in_user'])) { ?>
                <div class="navbar-start to-hide">
                    <a id="add-new-2" class="button is-warning" style="margin-top: 5px;" onclick="redirectToCreation()"><b>+ Create new!</b></a>
                </div>
            <?php } ?>
            <div class="navbar-end">
                <div class="navbar-item">
                <?php
                    $user = isset($_SESSION['logged_in_user']) ? $_SESSION['logged_in_user'] : null;
                    echo $user
                        ? "
                            <div class='navbar-item has-dropdown is-hoverable'>
                                <h2 class='navbar-link to-hide'>Hello, $user</h2>
                                <div class='navbar-dropdown'>
                                    <a class='navbar-item' href='/profile'><b>My Profile</b></a>
                                    <a class='navbar-item' href='/pictures'><b>My Pictures</b></a>
                                    <a class='navbar-item' href='/preferences'><b>My Preferences</b></a>
                                </div>
                            </div>
                            <button class='button is-primary to-hide' onclick='signOut()'>
                                Sign out
                            </button>
                        "
                        : '
                            <div class="buttons to-hide">
                                <a href="/sign-up" class="button is-primary">
                                    <b>Sign up</b>
                                </a>
                                <a href="/sign-in" class="button is-light">
                                    <b>Sign in</b>
                                </a>
                            </div>
                        ';
                ?>
                </div>
            </div>
        </div>
    </div>
</nav>

<script type="text/javascript">
    const getAll = selector => {
        return Array.prototype.slice.call(document.querySelectorAll(selector), 0);
    }

    const addNewBtn = document.getElementById('add-new');
    const addNewBtn2 = document.getElementById('add-new-2');
    const burger = document.getElementById('burger');
    const menu = document.getElementById('navbarMenu');

    burger.addEventListener('click', el => {
        burger.classList.toggle('is-active');
        menu.classList.toggle('is-active');

        const hid = getAll('.to-hide');
        hid.map(h => h.style.display = 'none');
    });

    if (window.location.pathname === '/create-new-picture') {
        if (addNewBtn || addNewBtn2) {
            addNewBtn.style.display = 'none';
            addNewBtn2.style.display = 'none';
        }
    }

</script>

<script type="text/javascript" src="public/js/helpers.js"></script>
<script type="text/javascript" src="public/js/signOut.js"></script>
