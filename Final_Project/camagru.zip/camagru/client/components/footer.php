<footer class="footer">
    <div class="content has-text-centered">
        <p>
            Created as <a href="https://unit.ua"><strong>UNIT_Factory</strong></a> project by <b>vlvereta</b> &copy;
        </p>
    </div>
</footer>
