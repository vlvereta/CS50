<?php
    session_start();
    
    require_once('./init.php');
?>

<!DOCTYPE html>
<html>
<head>
    <title>Camagru</title>

    <meta charset="utf-8">
    <meta name="author" content="vlvereta">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="Study project at 42 school to learn web development basics.">

    <link rel="shortcut icon" type="image/png" href="/public/assets/favicon.png"/>

    <link rel="stylesheet" href="/public/css/main.css" />
    <link rel="stylesheet" href="/public/css/bulma.min.css" />
</head>
<body>
    <?php include __ROOT__ . '/client/components/header.php'; ?>

    <main id="root">
        <section class="section">
            <?php renderSection(); ?>
        </section>
    </main>

    <?php include __ROOT__ . '/client/components/footer.php'; ?>
</body>
</html>
