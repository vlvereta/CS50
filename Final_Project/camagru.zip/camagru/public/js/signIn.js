const signIn = () => {
  event.preventDefault();

  username = checkUsername();
  password = checkPassword();

  if (isErrors(['username', 'password'])) return;

  const url = 'api/controllers/signIn.php';
  const user = { username, password };
  const request = new Request(url, {
    method: 'POST',
    body: JSON.stringify(user),
    headers: new Headers({
      'Content-Type': 'application/json'
    })
  });

  fetch(request)
    .then(response => response.json())
    .then(json => {
      if (!json.success) {
        setErrorFromResponse(json.error);
      } else {
        window.location = '/';
      }
    })
    .catch(error => console.log(error));  // FIXME: handle error
};
