const pictures = document.getElementById('pictures');
const greetImg = document.getElementById('greet-img');

const likePicture = (pictureId) => {
  const url = 'api/services/likePicture.php';
  const payload = { picture_id: pictureId };
  const request = new Request(url, {
    method: 'POST',
    body: JSON.stringify(payload),
    headers: new Headers({
      'Content-Type': 'application/json'
    })
  });

  fetch(request)
    .then(response => response.json())
    .then(json => {
      const { data, success } = json;

      if (success) {
        const text = document.getElementById(`like-text-for-${pictureId}`);
        const amount = document.getElementById(`like-amount-for-${pictureId}`);
        text.innerHTML = data.isLiked ? 'Unlike' : 'Like';
        amount.innerHTML = ` · ${data.total}`;
      }
    })
};

const fetchPictureLikes = pictureId => {
  const url = 'api/services/getPictureLikes.php';
  const payload = { picture_id: pictureId };
  const request = new Request(url, {
    method: 'POST',
    body: JSON.stringify(payload),
    headers: new Headers({
      'Content-Type': 'application/json'
    })
  });

  return fetch(request)
    .then(response => response.json())
    .then(({ data }) => data)
    .catch(error => console.log(error));
};

const commentPicture = pictureId => {
  const textarea = document.getElementById("new-comment-for-" + pictureId);
  if (textarea.value) {
    const url = 'api/services/commentPicture.php';
    const payload = {
      picture_id: pictureId,
      comment: textarea.value
    };
    const request = new Request(url, {
      method: 'POST',
      body: JSON.stringify(payload),
      headers: new Headers({
        'Content-Type': 'application/json'
      })
    });

    fetch(request)
      .then(response => response.json())
      .then(json => {
        textarea.value = '';

        const { data: { username, comment }, success } = json;
        if (success) {
          const newCommentArticle = createCommentBlock(username, comment);
          const commentList = document.querySelector(`div#comment-list-${pictureId}`);
          commentList.appendChild(newCommentArticle);
        }
      });
  }
};

const fetchPictureComments = pictureId => {
  const url = 'api/services/getPictureComments.php';
  const payload = { picture_id: pictureId };
  const request = new Request(url, {
    method: 'POST',
    body: JSON.stringify(payload),
    headers: new Headers({
      'Content-Type': 'application/json'
    })
  });

  return fetch(request)
    .then(response => response.json())
    .then(({ data }) => data)
    .catch(error => console.log(error));
};

const createCommentBlock = (author, comment) => {
  const commentArticle = document.createElement('article');
  commentArticle.classList.add('media');
  commentArticle.innerHTML =
    '<figure class="media-left">' +
      '<p class="image is-64x64">' +
        '<img src="/public/assets/avatars/user.png">' +
      '</p>' +
    '</figure>' +
    '<div class="media-content">' +
      '<div class="content">' +
        '<p>' +
            '<strong>' + author + '</strong>' +
            '<br>' + comment + '<br>'
        '</p>' +
      '</div>' +
    '</div>';
  return commentArticle;
};

const buildCard = (id, username, timestamp, img = '', filter, likes, comments) => {
  const card = document.createElement('div');
  card.classList.add('box');
  card.classList.add('has-text-centered');
  card.classList.add('gray-card-background');

  if (username && timestamp) {
    const level = document.createElement('div');
    level.classList.add('level');
    card.appendChild(level);

    const leftLevel = document.createElement('div');
    leftLevel.classList.add('level-left');
    level.appendChild(leftLevel);

    const levelItem1 = document.createElement('div');
    levelItem1.classList.add('level-item');
    leftLevel.appendChild(levelItem1);

    const usernameTitle = document.createElement('h5');
    usernameTitle.classList.add('subtitle');
    usernameTitle.classList.add('is-5');
    usernameTitle.classList.add('is-italic');
    usernameTitle.innerHTML = username;
    levelItem1.appendChild(usernameTitle);

    const rightLevel = document.createElement('div');
    rightLevel.classList.add('level-right');
    level.appendChild(rightLevel);

    const levelItem2 = document.createElement('div');
    levelItem2.classList.add('level-item');
    rightLevel.appendChild(levelItem2);

    const dateTitle = document.createElement('h5');
    dateTitle.classList.add('subtitle');
    dateTitle.classList.add('is-5');
    dateTitle.classList.add('is-italic');
    dateTitle.innerHTML = getHumanDate(timestamp);
    levelItem2.appendChild(dateTitle);

    const hr = document.createElement('hr');
    card.appendChild(hr);
  }

  // picture
  const image = document.createElement('img');
  image.style.maxHeight = '500px';
  image.src = img;
  image.classList.add(filter);
  card.appendChild(image);

  // likes
  const likeRow = document.createElement('p');
  if (likes.isAbleToLike) {
    const likeText = document.createElement('a');
    likeText.addEventListener('click', () => likePicture(id));
    likeText.id = `like-text-for-${id}`;
    likeText.innerHTML = likes.isLiked ? 'Unlike' : 'Like';
    likeRow.appendChild(likeText);
  }
  const likeAmount = document.createElement('span');
  likeAmount.innerHTML = `${!likes.isAbleToLike ? 'Likes' : ''} · ${likes.total}`;
  likeAmount.id = `like-amount-for-${id}`;
  likeRow.appendChild(likeAmount);
  card.appendChild(likeRow);

  const commentList = document.createElement('div');
  commentList.id = `comment-list-${id}`;
  card.appendChild(commentList);
  comments.comments.map(({ username, text }) => {
    const createdComment = createCommentBlock(username, text);
    commentList.appendChild(createdComment);
  });
  
  if (comments.isAbleToComment) {
    const newComment = document.createElement('article');
    newComment.classList.add('media');
    newComment.innerHTML =
      '<figure class="media-left">' +
        '<p class="image is-64x64">' +
          '<img src="/public/assets/avatars/user.png">' +
        '</p>' +
      '</figure>' +
      '<div class="media-content">' +
        '<div class="field">' +
          '<p class="control">' +
              '<textarea id="new-comment-for-' + id + '" class="textarea" placeholder="Add a comment..."></textarea>' +
          '</p>' +
        '</div>' +
        '<div class="field">' +
          '<p class="control">' +
            '<button class="button" onclick="commentPicture(' + id + ')">Post comment</button>' +
          '</p>' +
        '</div>' +
      '</div>';
    card.appendChild(newComment);
  }

  return card;
};

/** Fetch pictures with pagination */

let pageNumber = 1;
let visibility = false;

const loader = document.querySelector('button#loader');

const isElementInViewport = (el) => {
  const rect = el.getBoundingClientRect();

  return (
    rect.top >= 0 &&
    rect.left >= 0 &&
    rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
    rect.right <= (window.innerWidth || document.documentElement.clientWidth)
  );
};

const onVisibilityChange = (el, callback) => () => {
  const newVisibility = isElementInViewport(el);

  if (newVisibility != visibility) {
    visibility = newVisibility;
    callback();
  }
};

const fetchHandler = onVisibilityChange(loader, () => {
  const url = 'api/services/getPictures.php';
  const payload = { page: pageNumber };
  const request = new Request(url, {
    method: 'POST',
    body: JSON.stringify(payload),
    headers: new Headers({
      'Content-Type': 'application/json'
    })
  });

  fetch(request)
    .then(response => response.json())
    .then(({ data }) => {

      if (data && data.length) {
        data.map(async ({ id, username, picture, filter, created_at }) => {
          const likes = await fetchPictureLikes(id);
          const comments = await fetchPictureComments(id);
          const card = buildCard(id, username, created_at, picture, filter, likes, comments);
          pictures.appendChild(card);
        });
        pageNumber++;
      } else if ((!data || !data.length) && pageNumber === 1) {
        greetImg.style.display = 'block';
        loader.style.display = 'none';
      } else {
        loader.style.display = 'none';
      }
    })
    .catch(error => console.log(error));
});

if (window.addEventListener) {
  addEventListener('DOMContentLoaded', fetchHandler, false);
  addEventListener('load', fetchHandler, false);
  addEventListener('scroll', fetchHandler, false);
  addEventListener('resize', fetchHandler, false);
} else if (window.attachEvent)  {
  attachEvent('onDOMContentLoaded', fetchHandler); // Internet Explorer 9+ :(
  attachEvent('onload', fetchHandler);
  attachEvent('onscroll', fetchHandler);
  attachEvent('onresize', fetchHandler);
}
