const signOut = () => {
    event.preventDefault();
  
    const url = 'api/controllers/signOut.php';
    const request = new Request(url, {
      method: 'POST',
      body: '',
      headers: new Headers({
        'Content-Type': 'application/json'
      })
    });
  
    fetch(request)
      .then(response => response.json())
      .then(() => window.location = '/')
      .catch(error => console.log(error));  // FIXME: handle error
  };
  