const likes = document.querySelector('input#likes');
const comments = document.querySelector('input#comments');

fetch('api/services/getPreferences.php')
  .then(response => response.json())
  .then(({ success, data }) => {
    if (success) {
      likes.checked = Number(data.is_likes);
      comments.checked = Number(data.is_comments);
    }
  })
  .catch(error => console.log(error));  // FIXME: handle error

const submitPreferences = () => {
  event.preventDefault();

  const url = 'api/services/setPreferences.php';
  const payload = { likes: likes.checked, comments: comments.checked };
  const request = new Request(url, {
    method: 'POST',
    body: JSON.stringify(payload),
    headers: new Headers({
      'Content-Type': 'application/json'
    })
  });

  fetch(request)
    .then(response => response.json())
    .then(json => json)
    .catch(error => console.log(error));  // FIXME: handle error
};
