const isGetUserMedia = () => !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);

let isAccessed = false;
let pictureCounter = 0;

if (isGetUserMedia()) {
  const fileInput = document.getElementById('file-input');

  const fileButton = document.querySelector('button#file');
  const snapshotButton = document.querySelector('button#snapshot');
  const discardButton = document.querySelector('button#discard');
  const saveButton = document.querySelector('button#save');
  const stickerSelect = document.querySelector('select#sticker');
  const filterBlock = document.getElementById('filter-block');
  const filterSelect = document.querySelector('select#filter');

  const video = document.querySelector('video');
  const canvas = document.querySelector('canvas');

  const showFirstLine = () => {
    discardButton.style.display = 'none';
    saveButton.style.display = 'none';

    filterBlock.style.display = 'block';
    if (isAccessed) {
      snapshotButton.style.display = 'block';
    } else {
      fileButton.style.display = 'block';
    }
  };

  const showSecondLine = () => {
    fileButton.style.display = 'none';
    filterBlock.style.display = 'none';
    snapshotButton.style.display = 'none';

    discardButton.style.display = 'block';
    saveButton.style.display = 'block';
  };

  navigator.mediaDevices.getUserMedia({ video: true })
    .then(stream => {
      window.stream = stream;
      video.srcObject = stream;

      return new Promise(resolve => video.onplaying = resolve);
    })
    .then(() => {
      isAccessed = true;
      filterBlock.style.display = 'initial';
      snapshotButton.classList.remove('is-static');
    })
    .catch(() => {
      fileButton.addEventListener('click', loadPicture);
      snapshotButton.style.display = 'none';
      filterBlock.style.display = 'initial';
      fileButton.style.display = 'initial';
    });

  const loadPicture = () => {
    fileInput.click();
      
      fileInput.onchange = e => {
        const file = e.target.files[0];
        if (file.type.match('image.*')) {
          const reader = new FileReader();
          reader.readAsDataURL(file);
          reader.onload = e => {
            if (e.target.readyState == FileReader.DONE) {
              const image = new Image();
              image.src = e.target.result;
              image.onload = () => {
                canvasAction(image);
              };
            }
          }
        }
        fileInput.value = '';
      };
  };

  const canvasAction = (toShow, isImg = true) => {
    canvas.style.display = 'inline-block';
    
    const width = video.offsetWidth;
    const height = isImg
      ? width * toShow.height / toShow.width
      : video.offsetHeight;

    canvas.width = width;
    canvas.height = height;
    canvas.className = filterSelect.value;
    canvas.getContext('2d').drawImage(toShow, 0, 0, width, height);

    video.style.display = 'none';
    showSecondLine();
  };

  filterSelect.onchange = () => {
    video.className = filterSelect.value;
  };

  snapshotButton.onclick = () => canvasAction(video, false);

  discardButton.onclick = () => {
    canvas.style.display = 'none';
    video.style.display = 'inline-block';
    showFirstLine();
  };

  saveButton.onclick = () => {
    pictureCounter++;

    sendPicture(
      canvas.toDataURL('image/webp'),
      stickerSelect.options[stickerSelect.selectedIndex].value,
      filterSelect.options[filterSelect.selectedIndex].value
    );
    canvas.style.display = 'none';
    video.style.display = 'inline-block';
    showFirstLine();
  };

  const sendPicture = (picture, sticker, filter) => {
    fetch('api/controllers/uploads.php', {
      method: 'POST',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        "is_picture": true,
        picture,
        filter,
        sticker,
        "id": `pic-${Math.random()}-${pictureCounter}`
      })
    })
      .then(response => response.json())
      .then(({ success, data }) => {
        if (success && data) {
          const { filter, picture } = data;
          const currentPictureNumber = pictureCounter % 5;
          const imageTag = document.getElementById(`preview-${!currentPictureNumber ? '5' : currentPictureNumber}`);

          imageTag.classList.add(filter);
          imageTag.src = picture;
        }
      })
      .catch(error => console.log(error));  // FIXME: handle error
  };

} else {
  console.error('You must run application from secure environment.');
  console.warn('For developing purposes you can use next command: open -a "Google Chrome" --args --unsafely-treat-insecure-origin-as-secure="your_unsecure_url"')
}

// More info here: html5rocks.com/en/tutorials/getusermedia/intro/