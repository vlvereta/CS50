const title = document.getElementById('title');
const pictures = document.getElementById('pictures');

const buildCard = (id, img = '', filter) => {
  const column = document.createElement('div');
  column.classList.add('column');
  column.classList.add('is-3');
  column.id = `column-${id}`;
  const card = document.createElement('div');
  card.classList.add('card');
  const cardContent = document.createElement('div');
  cardContent.classList.add('card-content');
  const content = document.createElement('div');
  content.classList.add('content');
  content.classList.add('has-text-centered');
  const image = document.createElement('img');
  image.src = img;
  image.classList.add(filter);
  content.appendChild(image);
  const footer = document.createElement('footer');
  footer.classList.add('card-footer');
  const deleteBtn = document.createElement('a');
  deleteBtn.classList.add('card-footer-item');
  deleteBtn.href = "#";
  deleteBtn.innerHTML = 'Delete';
  deleteBtn.addEventListener('click', () => onDelete(id))

  column.appendChild(card);
  card.appendChild(cardContent);
  cardContent.appendChild(content);
  card.appendChild(footer);
  footer.appendChild(deleteBtn);

  return column;
};

const onDelete = pictureId => {
  const url = 'api/controllers/deletePicture.php';
  const payload = { picture_id: pictureId };
  const request = new Request(url, {
    method: 'POST',
    body: JSON.stringify(payload),
    headers: new Headers({
      'Content-Type': 'application/json'
    })
  });

  fetch(request)
    .then(() => document.getElementById(`column-${pictureId}`).style.display = 'none')
    .catch(error => console.log(error));  // FIXME: handle error
};

fetch('api/services/getUserPictures.php')
  .then(response => response.json())
  .then(({ data }) => {
    if (!data || !data.length) {
      const subTitle = document.createElement('h4');
      subTitle.classList.add('subtitle');
      subTitle.classList.add('is-4');
      subTitle.innerHTML = "No pictures yet..";
      title.appendChild(subTitle);
    } else {
      data.reverse();
      data.map(({ id, picture, filter }) => {
        const card = buildCard(id, picture, filter);
        pictures.appendChild(card);
      });
    }
  })
  .catch(error => console.log(error));
