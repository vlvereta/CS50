const recoveryPassword = () => {
  event.preventDefault();

  oldPassword = checkOldPassword();
  password = checkPassword();
  passwordConfirmation = checkPasswordConfirmation();

  if (isErrors(['oldPassword', 'password', 'passwordConfirmation'])) return;

  const url = 'api/controllers/recoveryPassword.php';
  const username = window.location.search && window.location.search.split('=')[1];
  const payload = { username, oldPassword, password, passwordConfirmation };
  const request = new Request(url, {
    method: 'POST',
    body: JSON.stringify(payload),
    headers: new Headers({
      'Content-Type': 'application/json'
    })
  });

  fetch(request)
    .then(response => response.json())
    .then(json => {
      if (!json.success) {
        setErrorFromResponse(json.error);
      } else {
        window.location = '/';
      }
    })
    .catch(error => console.log(error));  // FIXME: handle error
};
