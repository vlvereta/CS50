const redirectToCreation = () => window.location.href = '/create-new-picture';

const getHumanDate = timestamp => {
  const date = new Date(timestamp);

  const month = date.getMonth() + 1;

  return `${date.getDate()}/${month < 10 ? `0${month}` : month}/${date.getFullYear()}`
}
