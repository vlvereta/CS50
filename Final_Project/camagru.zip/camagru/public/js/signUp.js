const signUp = () => {
  event.preventDefault();

  username = checkUsername();
  email = checkEmail();
  password = checkPassword();
  passwordConfirmation = checkPasswordConfirmation();

  if (isErrors(['username', 'email', 'password', 'passwordConfirmation'])) return;

  const url = 'api/controllers/signUp.php';
  const newUser = { username, email, password, passwordConfirmation };
  const request = new Request(url, {
    method: 'POST',
    body: JSON.stringify(newUser),
    headers: new Headers({
      'Content-Type': 'application/json'
    })
  });

  fetch(request)
    .then(response => response.json())
    .then(json => {
      if (!json.success) {
        setErrorFromResponse(json.error);
      } else {
        window.location = '/';
      }
    })
    .catch(error => console.log(error));  // FIXME: handle error
};
