const forgotPassword = () => {
  event.preventDefault();

  email = checkEmail();

  if (isErrors(['email'])) return;

  const url = 'api/controllers/forgotPassword.php';
  const payload = { email };
  const request = new Request(url, {
    method: 'POST',
    body: JSON.stringify(payload),
    headers: new Headers({
      'Content-Type': 'application/json'
    })
  });

  fetch(request)
    .then(response => response.json())
    .then(json => {
      if (!json.success) {
        setErrorFromResponse(json.error);
      } else {
        window.location = '/';
      }
    })
    .catch(error => console.log(error));  // FIXME: handle error
};
