/** Fields */
const usernameField = document.querySelector('.username-field');
const emailField = document.querySelector('.email-field');
const passwordField = document.querySelector('.password-field');
const passwordConfirmationField = document.querySelector('.password-confirmation-field');
const oldPasswordField = document.querySelector('.old-password-field');

/** Inputs */
const usernameInput = document.querySelector('.username-input');
const emailInput = document.querySelector('.email-input');
const passwordInput = document.querySelector('.password-input');
const passwordConfirmationInput = document.querySelector('.password-confirmation-input');
const oldPasswordInput = document.querySelector('.old-password-input');

/** Helper text IDs */
const USERNAME_HID = 'username-hid';
const EMAIL_HID = 'email-hid';
const PASSWORD_HID = 'password-hid';
const PASSWORD_CONFIRMATION_HID = 'password-confirmation-hid';
const OLD_PASSWORD_HID = 'old-password-hid';

/** Objects */
const fields = {
  usernameField,
  emailField,
  passwordField,
  passwordConfirmationField,
  oldPasswordField
};
const inputs = {
  usernameInput,
  emailInput,
  passwordInput,
  passwordConfirmationInput,
  oldPasswordInput
};
const helpers = {
  username: USERNAME_HID,
  email: EMAIL_HID,
  password: PASSWORD_HID,
  passwordConfirmation: PASSWORD_CONFIRMATION_HID,
  oldPassword: OLD_PASSWORD_HID
};

const errors = {
  username: false,
  email: false,
  password: false,
  passwordConfirmation: false,
  oldPassword: false
};

const isErrors = fields => {
  return fields.some(key => errors[key]);
};

const removeErrorHandler = field => {
  if (!errors[field]) return;
  errors[field] = false;

  const helper = document.getElementById(helpers[field]);
  inputs[`${field}Input`].classList.remove('is-danger');
  if (helper) helper.remove();
};

/** Listeners */
['username', 'email', 'password', 'passwordConfirmation', 'oldPassword'].map(field => {
  const input = inputs[`${field}Input`];
  if (!input) return;

  input.addEventListener('focus', () => removeErrorHandler(field));
  input.addEventListener('input', () => removeErrorHandler(field));
});

/** Checkers */
const checkUsername = () => {
  const username = usernameInput.value;
  
  if (!errors.username && !validateUsername(username)) {
    errors.username = true;

    setInvalidField(
      usernameInput,
      usernameField,
      makeHelperText('Only letters and digits, 3-50 chars.', USERNAME_HID)
    );
    return null;
  }
  return username;
};

const checkEmail = () => {
  const email = emailInput.value;
  
  if (!errors.email && !validateEmail(email)) {
    errors.email = true;

    setInvalidField(
      emailInput,
      emailField,
      makeHelperText('Enter a valid email.', EMAIL_HID)
    );
    return null;
  }
  return email;
};

const checkPassword = () => {
  const password = passwordInput.value;
  
  if (!errors.password && !validatePassword(password)) {
    errors.password = true;

    setInvalidField(
      passwordInput,
      passwordField,
      makeHelperText('Your password doesn\'t strong enough (no whitespaces, 8-64 chars, letters and digits).', PASSWORD_HID)
    );
    return null;
  }
  return password;
};

const checkPasswordConfirmation = () => {
  if (!passwordInput) return null;
  
  const password = passwordInput.value;
  const passwordConfirmation = passwordConfirmationInput.value;
  
  if (!errors.passwordConfirmation && !validatePasswordConfirmation(password, passwordConfirmation)) {
    errors.passwordConfirmation = true;

    setInvalidField(
      passwordConfirmationInput,
      passwordConfirmationField,
      makeHelperText('Passwords are not the same.', PASSWORD_CONFIRMATION_HID)
    );
    return null;
  }
  return passwordConfirmation;
};

const checkOldPassword = () => {
  const oldPassword = oldPasswordInput.value;

  if (!errors.oldPassword && !validatePassword(oldPassword)) {
    errors.oldPassword = true;

    setInvalidField(
      oldPasswordInput,
      oldPasswordField,
      makeHelperText('Is it really your current password?', OLD_PASSWORD_HID)
    );
    return null;
  }
  return oldPassword;
};
