const validateUsername = username => {
  const pattern = /^[a-zA-Z0-9]{3,50}$/;
  return pattern.test(username);
};

const validateEmail = email => {
  const pattern = /^[a-zA-Z0-9.!#$%&'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  return pattern.test(email);
};

const validatePassword = password => {
  const pattern = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;
  return pattern.test(password);
};

const validatePasswordConfirmation = (password, passwordConfirmation) => {
  return password === passwordConfirmation;
};

const makeHelperText = (text, id) => {
  const p = document.createElement('p');
  p.className = 'help is-danger';
  p.innerHTML = text;
  p.id = id;

  return p;
};

const setInvalidField = (input, field, helper) => {
  input.classList.add('is-danger');
  field.append(helper);
};

const removeInvalidField = (input, helper) => {
  input.classList.remove('is-danger');
  helper.remove();
};

const setErrorFromResponse = error => {
  const { field, message } = error;
    errors[field] = true;

    setInvalidField(
      inputs[`${field}Input`],
      fields[`${field}Field`],
      makeHelperText(message, helpers[field])
    );
};
