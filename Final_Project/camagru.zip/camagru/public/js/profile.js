const updateUser = () => {
  event.preventDefault();

  // check for errors only on backend
  const username = usernameInput.value;
  const email = emailInput.value;
  const password = passwordInput.value;
  const passwordConfirmation = passwordConfirmationInput.value;
  const oldPassword = oldPasswordInput.value;

  const url = 'api/services/updateProfile.php';
  const updatedUser = { username, email, password, passwordConfirmation, oldPassword };
  const request = new Request(url, {
    method: 'POST',
    body: JSON.stringify(updatedUser),
    headers: new Headers({
      'Content-Type': 'application/json'
    })
  });

  fetch(request)
    .then(response => response.json())
    .then(json => {
      if (!json.success) {
        setErrorFromResponse(json.error);
      } else {
        window.location.reload();
      }
    })
    .catch(error => console.log(error));
};

const confirmation = document.getElementById('confirmation');
fetch('api/services/getUser.php')
  .then(response => response.json())
  .then(({ data }) => {
    if (data) {
      confirmation.innerHTML = Number(data['is_confirmed']) ? 'Confirmed' : 'Not Confirmed'
      confirmation.classList.add(Number(data['is_confirmed']) ? 'has-text-success' : 'has-text-danger');
      confirmation.style.display = 'block';

      usernameInput.value = data['username'];
      emailInput.value = data['email'];
    }
  })
  .catch(error => console.log(error));
